package uz.b25.service;

import java.io.File;
import java.util.StringJoiner;
import java.util.StringTokenizer;

public class App1 {
    public static void main(String[] args) {
        File file = new File("files/data.txt");

        // 1. Fayldagi eng uzun so'zni aniqlash
        // 2. Fayldagi barcha sonlar yig'indisini aniqlash
        // 3. Sonlarni alohida (numbers.txt), so'zlarni alohida
        // (words.txt) fayllarga ajratib yozish

//        String.join()
//        StringJoiner

    }
}
