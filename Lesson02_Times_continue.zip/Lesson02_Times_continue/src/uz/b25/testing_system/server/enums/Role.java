package uz.b25.testing_system.server.enums;

public enum Role {
    ADMIN, USER
}
