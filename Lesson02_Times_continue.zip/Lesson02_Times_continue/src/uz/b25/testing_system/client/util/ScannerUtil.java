package uz.b25.testing_system.client.util;

import java.util.Scanner;

public interface ScannerUtil {
    Scanner SCANNER_NUM = new Scanner(System.in);
    Scanner SCANNER_STR = new Scanner(System.in);
}
