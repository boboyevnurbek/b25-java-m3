package uz.b25.testing_system.client.ui;

public class TestUI {
    public static void solveTest() {

    }

    public static void showTestHistory() {

    }
}
