package uz.b25.time_api.localdate;

import java.time.LocalDate;

public class App9 {
    public static void main(String[] args) {
        LocalDate localDate = LocalDate.of(2022, 15, 35);
        System.out.println("localDate = " + localDate);
    }
}
