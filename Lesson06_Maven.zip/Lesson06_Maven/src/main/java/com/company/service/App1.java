package com.company.service;

public class App1 {
    public static void main(String[] args) {
        // json, xml
        // JSON = JavaScript Object Notation
        // In JSON, values must be one of the following data types:
        //
        // a string => "Java", 'Java'
        // a number => 10, 10.25, -3.14
        // an object (JSON object) => {"username":"diyorbek", age: 15}
        // an array => ["Java", "Database", 12, 15, true]
        // a boolean => true, false
        // null
    }
}
