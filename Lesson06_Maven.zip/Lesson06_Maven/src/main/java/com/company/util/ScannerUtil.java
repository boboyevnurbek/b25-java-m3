package com.company.util;

import java.util.Scanner;

public interface ScannerUtil {
    Scanner SCANNER_STR = new Scanner(System.in);
    Scanner SCANNER_NUM = new Scanner(System.in);
}
