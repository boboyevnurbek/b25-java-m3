package uz.b25.project_part.exceptions;

public class ValidException extends Exception {

    public ValidException(String s) {
        super(s);
    }
}
